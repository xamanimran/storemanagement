import { ProductDeleteComponent } from './components/product/product-delete/product-delete.component';
import { ProductUpdateComponent } from './components/product/product-update/product-update.component';
import { ProductCreateComponent } from './components/product/product-create/product-create.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { from } from 'rxjs';
import {HomeComponent} from './views/home/home.component';
import {ProductCrudComponent} from './views/product-crud/product-crud.component';
import './views/report/report.component';
import './views/purchase/purchase.component';
import './views/issue-report/issue-report.component';
import { ReportComponent } from './views/report/report.component';
import { PurchaseComponent } from './views/purchase/purchase.component';
import { IssueReportComponent } from './views/issue-report/issue-report.component';

const routes: Routes = [{
  path:"",
  component: HomeComponent
},
{
  path: "products",
  component:ProductCrudComponent
},
{
  path:"products/create",
  component:ProductCreateComponent

},
{
  path:"products/update/:id",
  component:ProductUpdateComponent

},
{
  path:"products/delete/:id",
  component:ProductDeleteComponent

},
{
  path:"Report",
  component:ReportComponent
},
{
  path: "purchase",
  component:PurchaseComponent
},
{
  path: "issuance-report",
  component:IssueReportComponent
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
