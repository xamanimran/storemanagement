export interface Product{
    id?:string
    barcode:string
    name: string
    uom:string
    unitprice: string
    totalprice:string
    quantityrecieved:string
    contactnumber:string
    billnum:string
    purchasedate:string
    
}