import { Component, OnInit } from '@angular/core';
import { Report } from '../product.model';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-read-report',
  templateUrl: './product-read-report.component.html',
  styleUrls: ['./product-read-report.component.css']
})
export class ProductReadReportComponent implements OnInit {

  

  report: Report[]
  displayedColumns = ['id','barcode', 'name','uom', 'totalQtyRecieved','totalQtyissued','stockinhand','reorderlevel','placeorder','estimatedcost']


  constructor(private productService: ProductService) { }

  ngOnInit(): void {
    this.productService.read_report().subscribe(report =>{
      this.report=report
      console.log(report)
    })
  }

}
