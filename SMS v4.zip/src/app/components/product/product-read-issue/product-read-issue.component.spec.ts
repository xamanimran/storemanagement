import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductReadIssueComponent } from './product-read-issue.component';

describe('ProductReadIssueComponent', () => {
  let component: ProductReadIssueComponent;
  let fixture: ComponentFixture<ProductReadIssueComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductReadIssueComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductReadIssueComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
