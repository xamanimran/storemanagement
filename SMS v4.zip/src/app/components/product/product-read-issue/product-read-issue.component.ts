import { ProductService } from './../product.service';
import { issueReport } from './../product.model';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-product-read-issue',
  templateUrl: './product-read-issue.component.html',
  styleUrls: ['./product-read-issue.component.css']
})
export class ProductReadIssueComponent implements OnInit {

  issueProduct: issueReport[]
  displayedColumns = ['reqno','barcode', 'name','uom', 'department','totalqtyissue','reqby', 'action']

  constructor(private productService: ProductService) { }

  ngOnInit(): void {
    this.productService.read_issue().subscribe(issueProduct =>{
      this.issueProduct=issueProduct
      console.log(issueProduct)
      
    })
  }

}
