export interface Product{
    id?:string
    barcode:string
    name: string
    uom:string
    unitprice: string
    totalprice:string
    quantityrecieved:string
    contactnumber:string
    billnum:string
    purchasedate:string
    
    
}

export interface issueReport{
    reqno:string
    id:string
    issuedate:string
    barcode:string
    name:string
    uom: string
    totalqtyissue: string
    department:string
    reqby: string
}

export interface Report{
    id:string
    barcode:string
    name: string
    uom: string
    totalQtyRecieved: string
    totalQtyissued: string
    stockinhand: string
    reorderlevel: string
    placeorder: string
    estimatedcost: string

}

export interface Purchase{
    billnum:string
    purchasedate:string
    barcode: string
    name: string
    uom: string
    totalQtyRecieved: string
    unitprice: string
    totalprice: string
    party: string
    contactparty: string
    warrenty:string

}

