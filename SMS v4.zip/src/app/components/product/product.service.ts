import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {MatSnackBar} from '@angular/material/snack-bar';
import { Observable } from 'rxjs';
import { Product, issueReport, Report, Purchase } from './product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  baseUrl = "http://localhost:3001/products"

  constructor( private snackBar: MatSnackBar, private http: HttpClient) { }

  showMessage(msg: string): void {
    this.snackBar.open(msg, 'X', {
      duration:3000,
      horizontalPosition: "right",
      verticalPosition: "top"
    })
  }

  create(product: Product): Observable<Product>{
    return this.http.post<Product>(this.baseUrl,product)
  }

  read(): Observable<Product[]>{
    return this.http.get<Product[]>(this.baseUrl)
  }

  readById(id: string): Observable<Product>{
    const url = `${this.baseUrl}/${id}`
    return this.http.get<Product>(url)
  }

  readByIdissue(id: string): Observable<issueReport>{
    const url = `${this.baseUrl}/${id}`
    return this.http.get<issueReport>(url)
  }

  update(product: Product): Observable<Product>{
    const url = `${this.baseUrl}/${product.id}`
    return this.http.put<Product>(url, product)
  }

  update_issue(issueProduct: issueReport): Observable<issueReport>{
    const url = `${this.baseUrl}/${issueProduct.reqno}`
    return this.http.put<issueReport>(url, issueProduct)
  }

  delete(id: string): Observable<Product>{
    const url = `${this.baseUrl}/${id}`
    return this.http.delete<Product>(url);
  }
  delete_issue(id: string): Observable<issueReport>{
    const url = `${this.baseUrl}/${id}`
    return this.http.delete<issueReport>(url);
  }

  issue(issueProduct: issueReport): Observable<issueReport>{
    return this.http.post<issueReport>(this.baseUrl,issueProduct)
  }

  read_issue(): Observable<issueReport[]>{
    return this.http.get<issueReport[]>(this.baseUrl)
  }

  read_report(): Observable<Report[]>{
    return this.http.get<Report[]>(this.baseUrl)
  }

  read_purchase(): Observable<Purchase[]>{
    return this.http.get<Purchase[]>(this.baseUrl)
  }



}
