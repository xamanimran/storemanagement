import { Component, OnInit } from '@angular/core';
import { Product, Purchase } from './../product.model';
import { ProductService } from './../../product/product.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-product-create-purchase',
  templateUrl: './product-create-purchase.component.html',
  styleUrls: ['./product-create-purchase.component.css']
})
export class ProductCreatePurchaseComponent implements OnInit {

  purchase: Purchase = {
    id:'',
    billnum:'',
    purchasedate:'',
    barcode: '',
    name: '',
    uom: '',
    totalQtyRecieved: '',
    unitprice: '',
    totalprice: '',
    party: '',
    contactparty: '',
    warrenty:''

  }

  constructor(private ProductService:ProductService, private router:Router) { }

  ngOnInit(): void {
  }

  createProductPurchase(): void {
    this.ProductService.createPurchase(this.purchase).subscribe(() => {
      this.ProductService.showMessage('Operation sucessful')
      this.router.navigate(['/purchase'])

    });
    
  }
  cancel(): void {
    this.router.navigate(['/purchase'])
  }


}
