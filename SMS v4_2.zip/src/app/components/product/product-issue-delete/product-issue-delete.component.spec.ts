import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductIssueDeleteComponent } from './product-issue-delete.component';

describe('ProductIssueDeleteComponent', () => {
  let component: ProductIssueDeleteComponent;
  let fixture: ComponentFixture<ProductIssueDeleteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductIssueDeleteComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductIssueDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
