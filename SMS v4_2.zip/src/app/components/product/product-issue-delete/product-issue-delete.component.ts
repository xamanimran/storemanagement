import { issueReport } from './../product.model';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-issue-delete',
  templateUrl: './product-issue-delete.component.html',
  styleUrls: ['./product-issue-delete.component.css']
})
export class ProductIssueDeleteComponent implements OnInit {
  issueProduct: issueReport;

  constructor(
    private productService: ProductService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    this.productService.readByIdissue(id).subscribe((issueProduct) => {
      this.issueProduct = issueProduct;
    });
  }

  deleteissueProduct(): void {
    this.productService.delete_issue(this.issueProduct.id).subscribe(() => {
      this.productService.showMessage("Product delete Successfully");
      this.router.navigate(["/issuance-report"]);
    });
  }

  cancel(): void {
    this.router.navigate(["/issuance-report"]);
  }
  

}
