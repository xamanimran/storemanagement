import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductIssueUpdateComponent } from './product-issue-update.component';

describe('ProductIssueUpdateComponent', () => {
  let component: ProductIssueUpdateComponent;
  let fixture: ComponentFixture<ProductIssueUpdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductIssueUpdateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductIssueUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
