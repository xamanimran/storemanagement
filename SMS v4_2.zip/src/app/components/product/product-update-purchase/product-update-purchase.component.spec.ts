import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductUpdatePurchaseComponent } from './product-update-purchase.component';

describe('ProductUpdatePurchaseComponent', () => {
  let component: ProductUpdatePurchaseComponent;
  let fixture: ComponentFixture<ProductUpdatePurchaseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductUpdatePurchaseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductUpdatePurchaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
