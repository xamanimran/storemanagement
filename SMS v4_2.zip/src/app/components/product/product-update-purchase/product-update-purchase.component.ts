import { Purchase } from './../product.model';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-update-purchase',
  templateUrl: './product-update-purchase.component.html',
  styleUrls: ['./product-update-purchase.component.css']
})
export class ProductUpdatePurchaseComponent implements OnInit {

  //@ts-ignore
  purchase = Purchase;

  constructor(
    private productService: ProductService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get("id");
    this.productService.readByIdpurchase(id).subscribe((purchase) => {
      this.purchase = purchase;
    });
  }

  updatePurchase(): void {
    this.productService.update_issue(this.purchase).subscribe(() => {
      this.productService.showMessage("Operation successfull");
      this.router.navigate(["/purchase"]);
    });
  }

  cancel(): void {
    this.router.navigate(["/purchase"]);
  }

}
