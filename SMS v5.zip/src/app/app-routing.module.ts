import { ProductUpdatePurchaseComponent } from './components/product/product-update-purchase/product-update-purchase.component';
import { ProductDeletePurchaseComponent } from './components/product/product-delete-purchase/product-delete-purchase.component';
import { ProductIssueUpdateComponent } from './components/product/product-issue-update/product-issue-update.component';
import { ProductIssueComponent } from './components/product/product-issue/product-issue.component';
import { ProductDeleteComponent } from './components/product/product-delete/product-delete.component';
import { ProductUpdateComponent } from './components/product/product-update/product-update.component';
import { ProductCreateComponent } from './components/product/product-create/product-create.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { from } from 'rxjs';
import {HomeComponent} from './views/home/home.component';
import {ProductCrudComponent} from './views/product-crud/product-crud.component';
import './views/report/report.component';
import './views/purchase/purchase.component';
import './views/issue-report/issue-report.component';
import { ReportComponent } from './views/report/report.component';
import { PurchaseComponent } from './views/purchase/purchase.component';
import { IssueReportComponent } from './views/issue-report/issue-report.component';
import { ProductIssueDeleteComponent } from './components/product/product-issue-delete/product-issue-delete.component';
import { ProductCreatePurchaseComponent } from './components/product/product-create-purchase/product-create-purchase.component';
import { LoginComponent } from './login/login.component';
import { AuthGuardService } from './auth-guard.service';
import { RequestComponent } from './request/request.component';

const routes: Routes = [{
  path:"",
  component: HomeComponent,
  
},
{
  path: "products",
  component:ProductCrudComponent,
  
},
{
  path: "request",
  component:RequestComponent,
},
{
  path:"products/create",
  component:ProductCreateComponent,

},
{
  path:"products/issue",
  component:ProductIssueComponent,

},
{
  path: 'login',
  component: LoginComponent
},
{
  path:"products/purchase",
  component:ProductCreatePurchaseComponent,
  

},
{
  path:"products/update/:id",
  component:ProductUpdateComponent,

},
{
  path:"products/issueupdate/:id",
  component:ProductIssueUpdateComponent

},
{
  path:"purchase/purchaseupdate/:id",
  component:ProductUpdatePurchaseComponent

},
{
  path:"products/delete/:id",
  component:ProductDeleteComponent

},
{
  path:"products/issuedelete/:id",
  component:ProductIssueDeleteComponent

},
{
  path:"purchase/purchasedelete/:id",
  component:ProductDeletePurchaseComponent

},
{
  path:"Report",
  component:ReportComponent,
  
},
{
  path: "purchase",
  component:PurchaseComponent,

},
{
  path: "issuance-report",
  component:IssueReportComponent,
  canActivate: [ AuthGuardService ]
  
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
