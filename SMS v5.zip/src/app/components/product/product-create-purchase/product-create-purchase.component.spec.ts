import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductCreatePurchaseComponent } from './product-create-purchase.component';

describe('ProductCreatePurchaseComponent', () => {
  let component: ProductCreatePurchaseComponent;
  let fixture: ComponentFixture<ProductCreatePurchaseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductCreatePurchaseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductCreatePurchaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
