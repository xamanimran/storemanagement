import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductDeletePurchaseComponent } from './product-delete-purchase.component';

describe('ProductDeletePurchaseComponent', () => {
  let component: ProductDeletePurchaseComponent;
  let fixture: ComponentFixture<ProductDeletePurchaseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductDeletePurchaseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductDeletePurchaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
