import { Purchase } from './../product.model';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../product.service';


@Component({
  selector: 'app-product-delete-purchase',
  templateUrl: './product-delete-purchase.component.html',
  styleUrls: ['./product-delete-purchase.component.css']
})
export class ProductDeletePurchaseComponent implements OnInit {
  //@ts-ignore
  purchase = Purchase;

  constructor(
    private productService: ProductService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    this.productService.readById(id).subscribe((purchase) => {
      this.purchase = purchase;
    });
  }

  deletePurchase(): void {
    this.productService.deletePurchase(this.purchase.id).subscribe(() => {
      this.productService.showMessage("Product delete sucesso!");
      this.router.navigate(["/purchase"]);
    });
  }

  cancel(): void {
    this.router.navigate(["/purchase"]);
  }

}
