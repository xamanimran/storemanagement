import { issueReport } from './../product.model';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-issue',
  templateUrl: './product-issue.component.html',
  styleUrls: ['./product-issue.component.css']
})
export class ProductIssueComponent implements OnInit {

  issueProduct: issueReport = {
    reqno:'',
    issuedate:'',
    barcode:'',
    name:'',
    uom: '',
    totalqtyissue: '',
    department: '',
    reqby: '',
    id:''
  }

  constructor(private ProductService:ProductService, private router:Router) { }

  ngOnInit(): void {
  }

  issuedProduct(): void {
    this.ProductService.issue(this.issueProduct).subscribe(() => {
      this.ProductService.showMessage('Operation sucessful')
      this.router.navigate(['/issuance-report'])

    });

  }
  cancel(): void {
    this.router.navigate(['/issuance-report'])
  }

}
