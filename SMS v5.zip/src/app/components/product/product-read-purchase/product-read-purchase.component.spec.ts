import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductReadPurchaseComponent } from './product-read-purchase.component';

describe('ProductReadPurchaseComponent', () => {
  let component: ProductReadPurchaseComponent;
  let fixture: ComponentFixture<ProductReadPurchaseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductReadPurchaseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductReadPurchaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
