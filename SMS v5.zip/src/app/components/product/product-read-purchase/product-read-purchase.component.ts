import { Component, OnInit } from '@angular/core';
import { Purchase } from '../product.model';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-read-purchase',
  templateUrl: './product-read-purchase.component.html',
  styleUrls: ['./product-read-purchase.component.css']
})
export class ProductReadPurchaseComponent implements OnInit {


  purchase: Purchase[]
  displayedColumns = ['id','billnum','barcode', 'name','uom', 'totalQtyRecieved','unitprice','totalprice','party','contactparty','warrenty','purchasedate','action']

  constructor(private productService: ProductService) { }

  ngOnInit(): void {
    this.productService.read_purchase().subscribe(purchase =>{
      this.purchase=purchase
      console.log(purchase)
    })
  

  }

}
