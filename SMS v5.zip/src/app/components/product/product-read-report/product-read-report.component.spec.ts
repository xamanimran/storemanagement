import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductReadReportComponent } from './product-read-report.component';

describe('ProductReadReportComponent', () => {
  let component: ProductReadReportComponent;
  let fixture: ComponentFixture<ProductReadReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProductReadReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductReadReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
