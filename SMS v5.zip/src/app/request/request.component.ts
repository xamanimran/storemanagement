import { requestproduct } from './../components/product/product.model';
import { Component, OnInit } from '@angular/core';
import { Product } from '../components/product/product.model';
import { ProductService } from '../components/product//product.service';

@Component({
  selector: 'app-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.css']
})
export class RequestComponent implements OnInit {

  request: requestproduct = {
    reqno:'',
    id:'',
    barcode:'',
    name:'',
    uom: '',
    totalqty: '',
    department: '',
    reqby: '',
    note: '',

  }

  constructor() { }

  ngOnInit(): void {
  }

}
