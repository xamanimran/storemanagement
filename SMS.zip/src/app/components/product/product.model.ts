export interface Product{
    id?:number
    barcode:string
    name: string
    uom:string
    unitprice: string
    totalprice:string
    quantityrecieved:string
    contactnumber:string
    billnum:string
    purchasedate:string
    
}