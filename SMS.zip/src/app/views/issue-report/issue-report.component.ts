import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-issue-report',
  templateUrl: './issue-report.component.html',
  styleUrls: ['./issue-report.component.css']
})
export class IssueReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
